create table madera(
idMadera identity primary key,
madCategoria varchar(30)not null, /*En la seccion categoria se diferenciaran por corta, larga, sobrantes*/
madTipo varchar(20)not null, /*Ver la familia de la madera */
madEstado varchar(15) not null, /*En stock, sin stock, robado */
madPrecio numeric not null
);