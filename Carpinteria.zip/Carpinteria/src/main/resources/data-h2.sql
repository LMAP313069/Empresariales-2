insert into madera values(1,'corta','pino','en stock',100.0);
insert into madera values(2,'larga','cedro','robado',150.0);