package isil.pe.maderaRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarpinteriaApplicaction {
    public static void main(String[] args) {
        SpringApplication.run(CarpinteriaApplicaction.class, args);
    }
}
