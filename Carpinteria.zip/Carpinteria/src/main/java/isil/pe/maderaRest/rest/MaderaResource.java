package isil.pe.maderaRest.rest;

import isil.pe.maderaRest.model.Madera;
import isil.pe.maderaRest.service.MaderaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class MaderaResource {

    @Autowired
    private MaderaService maderaService;


    @GetMapping("/products")
    public ResponseEntity getAll(){
        List<Madera> products = maderaService.findAll();

        if (products == null){
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity(products, HttpStatus.OK);
    }

    @PostMapping("/products")
    public ResponseEntity<Madera> create(@RequestBody Madera product){
        maderaService.create(product);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<Madera> update(@PathVariable Long id, @RequestBody Madera product){

        Madera productActual = maderaService.findById(id);

        if(productActual == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        productActual.setMadCategoria(product.getMadCategoria());
        productActual.setMadTipo(product.getMadTipo());
        productActual.setMadEstado(product.getMadEstado());
        productActual.setMadPrecio(product.getMadPrecio());

        maderaService.update(productActual);

        return new ResponseEntity<>(productActual, HttpStatus.OK);
    }

    @DeleteMapping("/products/{id}")
    public ResponseEntity delete(@PathVariable Long id){
        Madera productActual = maderaService.findById(id);
        if(productActual == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        maderaService.delete(id);

        return new ResponseEntity(HttpStatus.OK);
    }

    @GetMapping("/products/{id}")
    public ResponseEntity get(@PathVariable Long id){
        Madera productActual = maderaService.findById(id);

        if(productActual == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity(productActual, HttpStatus.OK);
    }
}
