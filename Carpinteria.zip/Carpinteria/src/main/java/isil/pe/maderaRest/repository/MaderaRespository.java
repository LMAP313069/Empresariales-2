package isil.pe.maderaRest.repository;

import isil.pe.maderaRest.model.Madera;

public interface MaderaRespository extends BaseRepository<Madera, Long> {
}
