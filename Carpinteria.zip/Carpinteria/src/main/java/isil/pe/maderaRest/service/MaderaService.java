package isil.pe.maderaRest.service;

import isil.pe.maderaRest.model.Madera;
import isil.pe.maderaRest.repository.JdbcMaderaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MaderaService {
@Autowired
    private JdbcMaderaRepository maderaRepository;
    public List<Madera> findAll(){
        //negocio
        return maderaRepository.findAll();
    }

    public void create(Madera product) {
        //negocio
        maderaRepository.create(product);
    }

    public Madera findById(Long id){
        return maderaRepository.findById(id);
    }

    public void update(Madera productActual) {
        maderaRepository.update(productActual);
    }

    public void delete(Long id){
        maderaRepository.delete(id);
    }
}
