package isil.pe.maderaRest.repository;

import isil.pe.maderaRest.model.Madera;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class JdbcMaderaRepository  implements  MaderaRespository{
    @Autowired private JdbcTemplate jdbcTemplate;

    @Override
    public void create(Madera product) {
        final String sql = "insert into madera(madCategoria, madTipo,madEstado,madPrecio) values (?, ?, ?, ?)";
        jdbcTemplate.update(sql, product.getMadCategoria(), product.getMadTipo(),product.getMadEstado(),product.getMadPrecio());
    }

    @Override
    public void update(Madera product) {
        final String sql = "update madera set madCategoria = ?, madTipo = ?, madEstado = ?, madPrecio = ? where idMadera = ?";
        jdbcTemplate.update(sql, product.getMadCategoria(), product.getMadTipo(),product.getMadEstado(),product.getMadPrecio(),product.getIdMadera());
    }

    @Override
    public void delete(Long id) {
        final String sql = "delete product where idMadera = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public List<Madera> findAll() {
        final String sql = "select * from madera";
        return jdbcTemplate.query(sql,JdbcMaderaRepository::ProductRowMapper);
    }

    @Override
    public Madera findById(Long id) {

        final String sql = "select * from madera where idMadera = ? ";

        return jdbcTemplate.queryForObject(sql,
                new Object[]{id},
                JdbcMaderaRepository::ProductRowMapper);
    }


    private static Madera ProductRowMapper(ResultSet resultSet, int i) throws SQLException {
        Long rsIdMadera = resultSet.getLong("idMadera");
        String madCategoria = resultSet.getString("madCategoria");
        String madTipo = resultSet.getString("madTipo");
        String madEstado = resultSet.getString("madEstado");
        Double madPrecio = resultSet.getDouble("madPrecio");

        return new Madera(rsIdMadera, madCategoria, madTipo,madEstado,madPrecio);
    }
}
