package isil.pe.maderaRest.model;

import lombok.AllArgsConstructor;
import lombok.Data;

//@AllArgsConstructor
@Data
public class Madera {
   private Long idMadera;
   private String madCategoria;
   private  String madTipo;
   private String madEstado;
   private Double madPrecio;

    public Madera() {
    }

    public Madera(Long idMadera, String madCategoria, String madTipo, String madEstado, Double madPrecio) {
        this.idMadera = idMadera;
        this.madCategoria = madCategoria;
        this.madTipo = madTipo;
        this.madEstado = madEstado;
        this.madPrecio = madPrecio;
    }


    public Long getIdMadera() {
        return idMadera;
    }

    public void setIdMadera(Long idMadera) {
        this.idMadera = idMadera;
    }

    public String getMadCategoria() {
        return madCategoria;
    }

    public void setMadCategoria(String madCategoria) {
        this.madCategoria = madCategoria;
    }

    public String getMadTipo() {
        return madTipo;
    }

    public void setMadTipo(String madTipo) {
        this.madTipo = madTipo;
    }

    public String getMadEstado() {
        return madEstado;
    }

    public void setMadEstado(String madEstado) {
        this.madEstado = madEstado;
    }

    public Double getMadPrecio() {
        return madPrecio;
    }

    public void setMadPrecio(Double madPrecio) {
        this.madPrecio = madPrecio;
    }
}
